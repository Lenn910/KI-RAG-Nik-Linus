# Arbeitsblatt 3 – Mini-RAG bauen

**Gruppe:** ____________________  **Domäne:** ____________________

> **Ziel:** Ihr baut für eure Domäne eine eigene Wissensbasis und seht im
> direkten Vorher/Nachher-Vergleich, was RAG bewirkt.
> **Hintergrund:** `docs/04_rag-erklaert.md`

---

## Teil A – Verstehen, was RAG ist

**A.1** Wofür steht die Abkürzung RAG?

Retrieval Augmented Generation

**A.2** Erkläre den Vergleich „Klassenarbeit ohne / mit Spickzettel" in eigenen
Worten:
Bei einer Klassenarbeit ohne Spickzettel muss man sich auf sein Wissen verlassen und bei einer Klassenarbeit mit Spickzettel liest man nur ab. 
_________________________________________________________________

**A.3** Nenne die zwei wichtigsten Faktoren für die Qualität eines RAG-Systems:

1. Qualität der Daten
2. Systempropmt

---

## Teil B – VORHER: Modell ohne Wissensbasis

> Wichtig: Dieser Schritt passiert **bevor** ihr Dokumente hochladet.

**B.1** Überlegt euch **5 Fachfragen** zu eurer Domäne, deren korrekte Antwort
ihr kennt. Tragt sie in die Tabelle ein und stellt sie dem Modell.

| # | Frage | Antwort korrekt? (ja/teils/nein) | Was war falsch? |
|---|-------|----------------------------------|-----------------|
| 1 |In welchen Modus muss ich wechseln, um den Hostnamen zu ändern, und wie lautet der exakte Befehl? |Nein |erfundene Bedienungsanleitung für Linux |
| 2 |Mit welchem Befehl sichere ich die aktuell laufende Konfiguration, damit sie nach einem Neustart nicht verloren geht? |Nein |erfundene Befehle |
| 3 |Was ist der Unterschied zwischen einem Access-Port und einem Trunk-Port bei einem Cisco-Switch? |falsch |OSI Modell durcheinander gebracht |
| 4 |Wie lauten die exakten Befehle, um ein neues VLAN mit der ID 20 und dem Namen "Gäste" anzulegen? |Falsch |Falsche Befehle |
| 5 |Wie kann ich mir den aktuellen Status und die IP-Adressen aller Schnittstellen (Interfaces) kompakt anzeigen lassen? |falsch |nicht existierende Befehle|

**B.2** Wie viele der 5 Antworten waren vollständig korrekt? 0 / 5

---

## Teil C – Wissensbasis erstellen

**C.1** Erstellt pro Thema eine Markdown-Datei (`.md`). Nutzt die Vorlage aus
`material/wissensbasis-vorlagen/` für eure Domäne als Startpunkt.

Achtet auf gute Struktur (siehe Checkliste in `docs/04_rag-erklaert.md`):
- klare Überschriften
- kurze Absätze
- Befehle/Code in Codeblöcken
- häufige Fehler benennen

**C.2** Welche Dateien habt ihr erstellt?

| Dateiname | Inhalt (Stichworte) |
|-----------|---------------------|
|cisco-Wissen | |
|Switch- | |
| | |

**C.3 System-Prompt setzen.** Legt in Open WebUI ein eigenes Modell an:
`Workspace → Models → + Create Model`, basierend auf `gemma3:1b`, mit einem
System-Prompt, der die Rolle festlegt (Vorlage in den Wissensbasis-Vorlagen).

Euer System-Prompt (Kurzfassung notieren):

_________________________________________________________________

---

## Teil D – NACHHER: Modell mit Wissensbasis

**D.1** Ladet eure Dokumente hoch
(`Workspace → Knowledge → + Create Knowledge`) und ordnet sie eurem Modell zu
(`Workspace → Models → (euer Modell) → Knowledge`).

**D.2** Stellt **dieselben 5 Fragen** aus Teil B erneut.

| # | Antwort jetzt korrekt? (ja/teils/nein) | Besser als vorher? |
|---|----------------------------------------|--------------------|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

**D.3** Wie viele sind **jetzt** korrekt? ______ / 5  (vorher: ______ / 5)

**D.4** Beschreibt den deutlichsten Unterschied, den ihr beobachtet habt:

_________________________________________________________________

_________________________________________________________________

---

## Teil E – Verbessern

**E.1** Wählt eine Frage, die noch nicht gut beantwortet wird. Verbessert das
zugehörige Dokument (mehr Details, klarere Struktur). Lade es neu hoch und teste
erneut. Was hat sich geändert?

_________________________________________________________________

---

✅ **Geschafft, wenn:** Ihr den Vorher/Nachher-Vergleich vollständig ausgefüllt
habt und eure Wissensbasis im RAG aktiv ist.
