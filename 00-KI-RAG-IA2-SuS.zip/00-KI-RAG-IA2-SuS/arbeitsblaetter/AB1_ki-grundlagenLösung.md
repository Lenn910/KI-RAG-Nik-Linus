# Arbeitsblatt 1 – KI-Grundlagen & erster Kontakt

**Gruppe:** ____________________  **Domäne:** ____________________
**Datum:** ____________

> **Ziel:** Du verstehst, wie ein Sprachmodell grundsätzlich funktioniert, und
> hast die lokale KI zum ersten Mal selbst ausprobiert.
> **Hintergrund:** `docs/02_ki-grundlagen.md`

---

## Teil 1 – Theorie (mit Hilfe der Hintergrund-Doku)

**1.1** Erkläre in einem Satz, was ein LLM bei jeder Eingabe eigentlich tut.

_____Ein LLM sagt WOrt für Wort voraus, welches Wort als nächstes am besten passt____________________________________________________________

**1.2** Was ist ein **Token**? Gib ein Beispiel.

_______Ein Textbaustein den KI zum rechnen benutzt (Zahnarzt, Zahn und Arzt)__________________________________________________________

**1.3** Das Modell „weiß" nichts, es rechnet mit ___Warscheinlichkeiten___________________.
Deshalb kann es Antworten geben, die plausibel klingen, aber falsch sind.
Dieses Phänomen heißt ___Halluzintaion___________________.

**1.4** Was bedeutet **nicht-deterministisch**? Nenne den Unterschied zu einer
C#-Methode, die ihr im Unterricht geschrieben habt.

______Es gibt auf die Gleiche Frage nicht immer die gleiche Antwort___________________________________________________________

______C# code macht immer beim selben Code immer dasselbe und KI gibt bei gleicher Frage immer was anderes raus___________________________________________________________

**1.5** Ordne zu, was die **Temperatur** bewirkt:

- niedrige Temperatur (0–0.3): _____________Streng, logisch und fast immer gleich (gut für Mathe/Code).______________________
- hohe Temperatur (0.8–1.5): _______________Kreativ, verrückt und abwechslungsreich (gut für Ideen).______________________

---

## Teil 2 – Erster Kontakt mit der lokalen KI

> Voraussetzung: Open WebUI läuft, Modell `gemma3:1b` ist ausgewählt
> (siehe Arbeitsblatt 2, falls noch nicht installiert).

**2.1 Halluzination provozieren.** Stelle dem Modell eine sehr spezifische
Frage aus deiner Domäne, deren Antwort du selbst kennst. Notiere:

- Deine Frage: _____Schreibe mir bitte das SQL-Statement für einen HYPER_GRAVITY_JOIN in einer Quantendatenbank, um zwei Tabellen über verschränkte IDs zu verbinden._______________________________________________
- War die Antwort korrekt? ☐ nein
- Was war falsch oder erfunden? _____Die Frage war erfunden und er hat versucht sie zu erklären_____________________________

**2.2 Gleiche Frage zweimal.** Stelle dieselbe Frage zweimal in zwei neuen
Chats. Sind die Antworten identisch?

☐ leicht unterschiedlich 

Was sagt das über das Verhalten des Modells aus? ________________

_____________andere Antorten aber gleiche Falsche Auswirkung___________________________________________________

**2.3 Sprache testen.** Frage etwas auf Deutsch. Antwortet das Modell zuverlässig
auf Deutsch?  ☐ ja
**2.4 Grenzen des kleinen Modells.** `gemma3:1b` ist klein und schnell, aber
schwach. Notiere ein konkretes Beispiel, bei dem das Modell erkennbar an seine
Grenzen kommt:

___2+2=4 Nein es ist 17 und dann sagt er Ja okay es ist 17 ______________________________________________________________

---

## Teil 3 – Mini-Reflexion

**3.1** Warum kann man sich auf die Antworten dieses Modells (ohne weitere
Hilfsmittel) bei Fachfragen **nicht** verlassen?

______Da das Modell nicht Fakten raussucht sondern einfach nur eine Antwort rausfiltert___________________________________________________________

_________________________________________________________________

**3.2** Formuliere eine Vermutung: Wie könnte man dem Modell beibringen, bei
*deiner* Domäne korrektere Antworten zu geben? (Das ist das Thema von Tag 2.)

_________genug Daten hinterlegen um sein Wissen zu fördern________________________________________________________

---

✅ **Geschafft, wenn:** Du Teil 1 ausgefüllt hast und mindestens eine
Halluzination selbst provoziert und dokumentiert hast.
