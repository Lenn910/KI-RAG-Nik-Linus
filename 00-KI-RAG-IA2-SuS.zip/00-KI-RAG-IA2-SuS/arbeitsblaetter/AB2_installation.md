# Arbeitsblatt 2 – Installation der lokalen KI-Umgebung

**Gruppe:** ____________________  **Domäne:** ____________________

> **Ziel:** Ihr habt Docker, Ollama und Open WebUI eingerichtet und das Modell
> `gemma3:1b` läuft.
> **Hintergrund:** `docs/03_installation.md` · Bei Fehlern: `docs/05_troubleshooting.md`

---

## Architektur – was läuft wo?

Trage ein, wo welche Komponente läuft (im Container / direkt auf dem PC):

| Komponente | läuft … | Port |
|------------|---------|------|
| Open WebUI | _______Im Container___________ | 3000/9000______ |
| Ollama | ______Im Conatiner____________ | _11434_____ |
| gemma3:1b | (im Modell-Speicher von Ollama) | – |

---

## Checkliste Installation

Hake ab, sobald ein Schritt erledigt und geprüft ist.

- [ ] **Docker Desktop** läuft (`docker --version` zeigt eine Version)
- [ ] **Ollama installiert** (`ollama --version`)
- [ ] **Umgebungsvariable** `OLLAMA_HOST = 0.0.0.0` gesetzt
- [ ] **Modell geladen** (`ollama pull gemma3:1b`)
- [ ] **Compose-Datei** im Projektordner
- [ ] **Container gestartet** (`docker compose up -d`)
- [ ] **WebUI erreichbar** unter `http://localhost:3000`
- [ ] **Account angelegt** (lokal)
- [ ] **Modell `gemma3:1b`** in der Auswahl sichtbar
- [ ] **Erste Antwort** erhalten

---

## Prüf-Befehle (Ergebnis notieren)

**Ollama läuft?**
```bash
curl http://localhost:11434
```
Ausgabe: _______Ollama is running_____________________________________

**Welche Modelle sind installiert?**
```bash
curl http://localhost:11434/api/tags
```
Gefundene Modelle: ___C:\Users\Nik Steuernagel\Desktop\IA2A Schule\Projekttag\KIProjekt\00-KI-RAG-IA2-SuS\00-KI-RAG-IA2-SuS\material\compose>curl http://localhost:11434/api/tags
{"models":[{"name":"gemma3:1b","model":"gemma3:1b","modified_at":"2026-06-22T23:37:55.2494168+02:00","size":815319791,"digest":"8648f39daa8fbf5b18c7b4e6a8fb4990c692751d49917417b8842ca5758e7ffc","details":{"parent_model":"","format":"gguf","family":"gemma3","families":["gemma3"],"parameter_size":"999.89M","quantization_level":"Q4_K_M"},"capabilities":["completion"]}]}________________________________

---

## Fehler-Protokoll

Notiert **jedes** Problem und wie ihr es gelöst habt – das ist später Teil eurer
Dokumentation und hilft anderen Gruppen!

| Problem | Lösung | gelöst? |
|---------|--------|---------|
| | | ☐ |
| | | ☐ |
| | | ☐ |

> **Tipp:** Die drei häufigsten Fehler sind: (1) WebUI findet kein Modell →
> `host.docker.internal` statt `localhost`; (2) `OLLAMA_HOST` nicht gesetzt;
> (3) Firewall blockiert Port 11434. Alle Lösungen in `docs/05_troubleshooting.md`.

---

✅ **Geschafft, wenn:** Das Modell `gemma3:1b` in Open WebUI antwortet und euer
Fehler-Protokoll ausgefüllt ist.
